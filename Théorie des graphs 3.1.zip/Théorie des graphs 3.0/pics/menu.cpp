#include "menu.h"
#include "graph.h"
void menu (BITMAP* ecran, BITMAP* menu1, BITMAP* menu2, BITMAP* foret, BITMAP* marin, BITMAP* jurassic)
{
    int m=0;
    while(!key[KEY_ESC])
    {
        if(key[KEY_SPACE] && m==0)
        {
            m=1;
            key[KEY_SPACE]=0;
        }
        if(m==0)
        {
            blit(menu,buffer,0,0,0,0,800,600);
        }
        else if(m==1)
        {
            blit(menu2,buffer,0,0,0,0,800,600);
        }

        if(m==1)
        {
            if(mouse_x>=10 && mouse_x<=180 && mouse_y>=10 && mouse_y<=40 && mouse_b==1)
            {
                m=2;
            }
            if(mouse_x>=370 && mouse_x<=650 && mouse_y>=200 && mouse_y<=330 && mouse_b==1)
            {
                blit(foret,buffer,0,0,0,0,800,600);
                m=3;
            }
            if(mouse_x>=30 && mouse_x<=320 && mouse_y>=400 && mouse_y<=540 && mouse_b==1)
            {
                blit(jurassic,buffer,0,0,0,0,800,600);
                m=4;
            }
            if(mouse_x>=470 && mouse_x<=750 && mouse_y>=350 && mouse_y<=490 && mouse_b==1)
            {
                blit(marin,buffer,0,0,0,0,800,600);
                m=5;
            }
        }

        if(m==2)
        {
            blit(menu,buffer,0,0,0,0,800,600);

        }
        if(m==3)
        {
            blit(foret,buffer,0,0,0,0,800,600);
            //foret(foret);

        }
        if(m==4)
        {
            blit(jurassic,buffer,0,0,0,0,800,600);
            //jurassic(jurassic);

        }
        if(m==5)
        {
            blit(marin,buffer,0,0,0,0,800,600);
            //marin(marin);

        }
        blit(buffer,screen,0,0,0,0,800,600);
    }
}
