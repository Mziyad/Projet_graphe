#include "grman/grman.h"
#include <iostream>
#include "menu.h"
#include "graph.h"

int main()
{
    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    /// Le nom du r�pertoire o� se trouvent les images � charger
    grman::set_pictures_path("pics");

    /// Un exemple de graphe
    Graph g;

    ///D�claration de la bitmap menu
    BITMAP* ecran=create_bitmap(800,600);
    ///appel du menu principal
    menu(ecran);

    //g.supprimer_arrete(3); /// supression arr�te d'indice 1
    //g.supprimer_arrete(2); /// supression arr�te d'indice 1
    //g.new_graph();
    std::string image ;
    std::cout << " entrez le nom du graph a ouvrir : ";
    std::cin>>image;
    g.charger_graphe(image);

    /// supression arr�te d'indice 1
    //g.supprimer_sommet(7);

    /// Vous gardez la main sur la "boucle de jeu"
    /// ( contrairement � des frameworks plus avanc�s )
    while ( !key[KEY_ESC] )
    {

        /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
        g.update();

        /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
        grman::mettre_a_jour();
        g.ajouter_sommet();
        g.ajouter_arrete();
        g.supprimer_sommet();
        g.supprimer_arrete_choix();

    }
    g.update_graph(image);
//    g.update_arc(image);

    grman::fermer_allegro();

    return 0;

}
END_OF_MAIN();


