#include <iostream>
#include <time.h>
#include <math.h>
#include <allegro.h>
#include <fstream>
#include "menu.h"
#include "graph.h"

//Lancement du menu principal
void menu (BITMAP* ecran)
{
    //chargement de la bitmap du menu principal
    BITMAP* menu1=load_bitmap("menu.bmp", NULL);
    while (!key[KEY_SPACE])
    {
        //affichage du menu principal
        blit(menu1, screen,0,0,0,0,800,600);
        //appel du menu secondaire lorsqu'on appuie sur "espace"
        if(key[KEY_SPACE])
        {
            menu2(ecran);
        }
    }
}

//Sous-prog du menu secondaire
void menu2(BITMAP* ecran)
{
    //chargement de la bitmap du menu secondaire
    BITMAP* menu2=load_bitmap("menu2.bmp",NULL);
    int a = 0;
    //boucle pour faire tourner le menu
    while (a == 0 )
    {
        //affichage du menu
        blit(menu2, screen,0,0,0,0,800,600);
        //choix du milieu selon les coordonnees/clicks de souris
        if(mouse_x>=10 && mouse_x<=180 && mouse_y>=10 && mouse_y<=40 && mouse_b==1)
        {
            a=1;            //retour au menu principal
            menu(ecran);    //appel du sous prog du menu principal
        }
        //menu foret
        if(mouse_x>=370 && mouse_x<=650 && mouse_y>=200 && mouse_y<=330 && mouse_b==1)
        {
            a=2;
            while(a==2)
            {
                foret(ecran);
            }
        }
        //menu jurassic
        if(mouse_x>=30 && mouse_x<=320 && mouse_y>=400 && mouse_y<=540 && mouse_b==1)
        {
            a=3;
            while(a==3)
            {
                jurassic(ecran);
            }
        }
        //menu marin
        if(mouse_x>=470 && mouse_x<=750 && mouse_y>=350 && mouse_y<=490 && mouse_b==1)
        {
            a=4;
            while(a==4)
            {
                marin(ecran);
            }
        }

    }

}

//sous prog menu foret
void foret(BITMAP* ecran)
{
    //chargement et affichage des bitmaps
    BITMAP* foret1=load_bitmap("foret.bmp", NULL);
    BITMAP* foret2=load_bitmap("foret2.bmp", NULL);
    blit(foret1,screen,0,0,0,0,800,600);
    if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
    {
        menu2(ecran);   //retour au menu 2
    }
    if(mouse_x>=450 && mouse_x<=750 && mouse_y>=300 && mouse_y<=400 && mouse_b==1)
    {
        bool b=true;
        while(b==true)
        {
            //lancement graphe
            blit(foret2,screen,0,0,0,0,800,600);
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
            {
                foret(ecran);  //retour menu foret
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=150 && mouse_y<=210 && mouse_b==1)
            {
                //appeler fonction ajout sommet
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=250 && mouse_y<=310 && mouse_b==1)
            {
                //appeler fonction suppression sommet
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=350 && mouse_y<=410 && mouse_b==1)
            {
                //appeler fonction ajout arete
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=450 && mouse_y<=510 && mouse_b==1)
            {
                //appeler fonction suppression arete
            }
        }
    }

}

//sous prog menu marin
void marin(BITMAP* ecran)
{
    //chargement et affichage des bitmaps
    BITMAP* marin1=load_bitmap("marin.bmp", NULL);
    BITMAP* marin2=load_bitmap("marin2.bmp", NULL);
    blit(marin1,screen,0,0,0,0,800,600);
    if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
    {
        menu2(ecran);   //retour au menu 2
    }
    if(mouse_x>=450 && mouse_x<=750 && mouse_y>=300 && mouse_y<=400 && mouse_b==1)
    {
        bool b=true;
        while(b==true)
        {
            //lancement graphe
            blit(marin2,screen,0,0,0,0,800,600);
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
            {
                    marin(ecran);   //retour menu marin
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=150 && mouse_y<=210 && mouse_b==1)
            {
                //appeler fonction ajout sommet
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=250 && mouse_y<=310 && mouse_b==1)
            {
                //appeler fonction suppression sommet
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=350 && mouse_y<=410 && mouse_b==1)
            {
                //appeler fonction ajout arete
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=450 && mouse_y<=510 && mouse_b==1)
            {
                //appeler fonction suppression arete
            }
        }
    }
}

//sous prog menu jurassic
void jurassic(BITMAP* ecran)
{
    //chargement et affichage des bitmaps
    BITMAP* jurassic1=load_bitmap("jurassic.bmp", NULL);
    BITMAP* jurassic2=load_bitmap("jurassic2.bmp", NULL);
    blit(jurassic1,screen,0,0,0,0,800,600);
    if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
    {
        menu2(ecran);   //retour au menu 2
    }
    if(mouse_x>=450 && mouse_x<=750 && mouse_y>=300 && mouse_y<=400 && mouse_b==1)
    {
        bool b=true;
        while(b==true)
        {
            //chargement graphe
            blit(jurassic2,screen,0,0,0,0,800,600);
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
            {
                    jurassic(ecran);    //retour menu jurassic
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=150 && mouse_y<=210 && mouse_b==1)
            {
                //appeler fonction ajout sommet
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=250 && mouse_y<=310 && mouse_b==1)
            {
                //appeler fonction suppression sommet
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=350 && mouse_y<=410 && mouse_b==1)
            {
                //appeler fonction ajout arete
            }
            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=450 && mouse_y<=510 && mouse_b==1)
            {
                //appeler fonction suppression arete
            }
        }
    }

}
