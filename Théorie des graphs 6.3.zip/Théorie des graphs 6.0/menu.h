#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include <iostream>
#include <fstream>
#include <time.h>
#include <allegro.h>
#include <math.h>
#include "graph.h"

void menu (BITMAP* ecran);
void menu2 (BITMAP* ecran);
void foret (BITMAP* ecran);
void marin (BITMAP* ecran);
void jurassic (BITMAP* ecran);
void regles (BITMAP* ecran);

static Graph g;

#endif // MENU_H_INCLUDED
