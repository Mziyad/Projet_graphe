#include "grman/grman.h"
#include <iostream>
#include "menu.h"
#include "graph.h"

int main()
{
    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    /// Le nom du r�pertoire o� se trouvent les images � charger
    grman::set_pictures_path("pics");

    /// Un exemple de graphe
    Graph g;

    ///D�claration de la bitmap menu
    BITMAP* ecran=create_bitmap(800,600);
    ///appel du menu principal
    menu(ecran);
    grman::fermer_allegro();

    return 0;
}
END_OF_MAIN();


