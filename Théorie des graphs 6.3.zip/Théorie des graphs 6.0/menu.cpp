#include <iostream>
#include <time.h>
#include <math.h>
#include <allegro.h>
#include <fstream>
#include "menu.h"
#include "graph.h"

//Lancement du menu principal
void menu (BITMAP* ecran)
{
    //chargement de la bitmap du menu principal
    BITMAP* menu1=load_bitmap("menu.bmp", NULL);
    while (!key[KEY_SPACE])
    {
        //affichage du menu principal
        blit(menu1, screen,0,0,0,0,800,600);
        //appel du menu secondaire lorsqu'on appuie sur "espace"
        if(key[KEY_SPACE])
        {
            menu2(ecran);
        }
    }
}

//Sous-prog du menu secondaire
void menu2(BITMAP* ecran)
{
    //chargement de la bitmap du menu secondaire
    BITMAP* menu2=load_bitmap("menu2.bmp",NULL);
    int a = 0;
    //boucle pour faire tourner le menu
    while (a == 0 )
    {
        //affichage du menu
        blit(menu2, screen,0,0,0,0,800,600);
        //choix du milieu selon les coordonnees/clicks de souris
        if(mouse_x>=10 && mouse_x<=180 && mouse_y>=10 && mouse_y<=40 && mouse_b==1)
        {
            a=1;            //retour au menu principal
            menu(ecran);    //(appel du sous prog du menu principal)
        }
        //menu foret
        if(mouse_x>=370 && mouse_x<=650 && mouse_y>=200 && mouse_y<=330 && mouse_b==1)
        {
            a=2;
            while(a==2)
            {
                foret(ecran);
            }
        }
        //menu jurassic
        if(mouse_x>=30 && mouse_x<=320 && mouse_y>=400 && mouse_y<=540 && mouse_b==1)
        {
            a=3;
            while(a==3)
            {
                jurassic(ecran);

            }
        }
        //menu marin
        if(mouse_x>=470 && mouse_x<=750 && mouse_y>=350 && mouse_y<=490 && mouse_b==1)
        {
            a=4;
            while(a==4)
            {
                marin(ecran);
            }
        }
        //menu mode d'emploi
        if(mouse_x>=10 && mouse_x<=180 && mouse_y>=70 && mouse_y<=100 && mouse_b==1)
        {
            a=5;
            while(a==5)
            {
               regles(ecran);
            }
        }

    }

}

//sous prog menu foret
void foret(BITMAP* ecran)
{
    //chargement et affichage des bitmaps
    BITMAP* foret1=load_bitmap("foret.bmp", NULL);
    //BITMAP* foret2=load_bitmap("foret2.bmp", NULL);
    blit(foret1,screen,0,0,0,0,800,600);
    if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
    {
        menu2(ecran);   //retour au menu 2
    }

    if(mouse_x>=450 && mouse_x<=750 && mouse_y>=300 && mouse_y<=400 && mouse_b==1) ///si on clique sur charger graphe
    {

        std::string image ;
        std::cout << " entrez le nom du graph a ouvrir : ";
        std::cin>>image;
        g.charger_graphe(image);
        g.ToutesComposantesConnexes();

        /// supression arr�te d'indice 1

        /// Vous gardez la main sur la "boucle de jeu"
        /// ( contrairement � des frameworks plus avanc�s )
        while ( !key[KEY_ESC] )
        {

            /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
            g.update();

            /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
            grman::mettre_a_jour();
            g.ajouter_sommet();
            g.ajouter_arrete();
            g.supprimer_sommet();
            g.supprimer_arrete_choix();

            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
            {
                foret(ecran);  //retour menu foret
            }

            if(key[KEY_E])
            {
                menu(ecran);
            }

            if(key[KEY_T])
            {
                std::cout << "progression de 1 semaine " << std::endl;
                g.evo_temps();
            }

        }
        g.update_graph(image);
    }

    if(mouse_x>=60 && mouse_x<=350 && mouse_y>=300 && mouse_y<=400 && mouse_b==1) ///si on clique sur cr�er graphe
    {
        std::string name;
        std::cout<<"Entrez le nom du nouveau graph : ";
        std::cin>>name;
        g.new_graph(name);
        g.ToutesComposantesConnexes();

        /// Vous gardez la main sur la "boucle de jeu"
        /// ( contrairement � des frameworks plus avanc�s )
        while ( !key[KEY_ESC] )
        {

            /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
            g.update();

            /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
            grman::mettre_a_jour();
            g.ajouter_sommet();
            g.ajouter_arrete();
            g.supprimer_sommet();
            g.supprimer_arrete_choix();

            if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
            {
                foret(ecran);  //retour menu foret
            }

            if(key[KEY_E])
            {
                menu(ecran);
            }

        }
        g.update_graph(name);

    }
}

//sous prog menu marin
void marin(BITMAP* ecran)
{
    //chargement et affichage des bitmaps
    BITMAP* marin1=load_bitmap("marin.bmp", NULL);
    //BITMAP* marin2=load_bitmap("marin2.bmp", NULL);
    blit(marin1,screen,0,0,0,0,800,600);
    if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
    {
        menu2(ecran);   //retour au menu 2
    }
    if(mouse_x>=450 && mouse_x<=750 && mouse_y>=300 && mouse_y<=400 && mouse_b==1) ///si on clique sur charger
    {

        std::string image ;
        std::cout << " entrez le nom du graph a ouvrir : ";
        std::cin>>image;
        g.charger_graphe(image);
        g.ToutesComposantesConnexes();

        /// supression arr�te d'indice 1
        //g.supprimer_sommet(7);

        /// Vous gardez la main sur la "boucle de jeu"
        /// ( contrairement � des frameworks plus avanc�s )
        while ( !key[KEY_ESC] )
        {

            /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
            g.update();

            /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
            grman::mettre_a_jour();
            g.ajouter_sommet();
            g.ajouter_arrete();
            g.supprimer_sommet();
            g.supprimer_arrete_choix();

        }
        g.update_graph(image);

        if(mouse_x>=60 && mouse_x<=350 && mouse_y>=300 && mouse_y<=400 && mouse_b==1) ///si on clique sur cr�er graphe
        {

            std::string name;
            std::cout<<"Entrez le nom du nouveau graph : ";
            std::cin>>name;
            g.new_graph(name);
            g.ToutesComposantesConnexes();
            while ( !key[KEY_ESC] )
            {

                /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
                g.update();

                /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
                grman::mettre_a_jour();
                g.ajouter_sommet();
                g.ajouter_arrete();
                g.supprimer_sommet();
                g.supprimer_arrete_choix();

                if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
                {
                    marin(ecran);  //retour menu foret
                }

                if(key[KEY_E])
                {
                    menu(ecran);
                }

            }
            g.update_graph(name);

        }
    }
}

//sous prog menu jurassic
void jurassic(BITMAP* ecran)
{
    //chargement et affichage des bitmaps
    BITMAP* jurassic1=load_bitmap("jurassic.bmp", NULL);
    //BITMAP* jurassic2=load_bitmap("jurassic2.bmp", NULL);
    blit(jurassic1,screen,0,0,0,0,800,600);
    if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
    {
        menu2(ecran);   //retour au menu 2
    }
    if(mouse_x>=450 && mouse_x<=750 && mouse_y>=300 && mouse_y<=400 && mouse_b==1)
    {
        std::string image ;
        std::cout << " entrez le nom du graph a ouvrir : ";
        std::cin>>image;
        g.charger_graphe(image);
        g.ToutesComposantesConnexes();

        /// supression arr�te d'indice 1
        //g.supprimer_sommet(7);

        /// Vous gardez la main sur la "boucle de jeu"
        /// ( contrairement � des frameworks plus avanc�s )
        while ( !key[KEY_ESC] )
        {

            /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
            g.update();

            /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
            grman::mettre_a_jour();
            g.ajouter_sommet();
            g.ajouter_arrete();
            g.supprimer_sommet();
            g.supprimer_arrete_choix();

        }
        g.update_graph(image);

        if(mouse_x>=60 && mouse_x<=350 && mouse_y>=300 && mouse_y<=400 && mouse_b==1) ///si on clique sur cr�er graphe
        {

            std::string name;
            std::cout<<"Entrez le nom du nouveau graph : ";
            std::cin>>name;
            g.new_graph(name);
            g.ToutesComposantesConnexes();

            /// Vous gardez la main sur la "boucle de jeu"
            /// ( contrairement � des frameworks plus avanc�s )
            while ( !key[KEY_ESC] )
            {

                /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
                g.update();

                /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
                grman::mettre_a_jour();
                g.ajouter_sommet();
                g.ajouter_arrete();
                g.supprimer_sommet();
                g.supprimer_arrete_choix();

                if(mouse_x>=50 && mouse_x<=150 && mouse_y>=50 && mouse_y<=110 && mouse_b==1)
                {
                    jurassic(ecran);  //retour menu foret
                }

                if(key[KEY_E])
                {
                    menu(ecran);
                }

            }
            g.update_graph(name);

        }
    }

}

//sous prog regles (mode d'emploi des touches et fichiers)
void regles(BITMAP* ecran)
{
    //declaration et affichage de la bitmap
    BITMAP* regles=load_bitmap("regles.bmp", NULL);
    blit(regles,screen,0,0,0,0,800,600);
    if(mouse_x>=50 && mouse_x<=150 && mouse_y>=500 && mouse_y<=550 && mouse_b==1)
    {
        menu2(ecran);   //retour au menu 2
    }
}


